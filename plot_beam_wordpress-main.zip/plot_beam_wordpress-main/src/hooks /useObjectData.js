import axios from "axios";
import { useQuery } from "react-query";

/**
 * @typedef {Object} MeasureAxis
 * @property {number} min
 * @property {number} max
 */
/**
 * @typedef {Object} QlikObject
 * @property {string} visType
 * @property {string[]} dimensions
 * @property {string[]} measurements
 * @property {number[]} exactData
 * @property {MeasureAxis} measureAxis
 *
 */

/**
 * Custom hook to fetch object data.
 * @function
 * @param {string} objectID - The ID of the object.
 * @param {string} appID - The ID of the app.
 * @returns {QlikObject} - The object containing the query data.
 */
const useObjectData = (objectID, appID) => {
	return useQuery({
		queryKey: ["object", objectID, appID],
		// enabled: objectID !== null,
		queryFn: async () => {
			try {
				const data = await axios.get(
					"https://pg-qlik.onrender.com/api/qlik/object",
					{
						headers: {
							Accept: "application/json, text/plain, */*",
							"Content-Type": null,
							"Access-Control-Allow-Origin": true,
						},
						params: {
							objectID: objectID,
							appID: appID,
						},
					}
				);
				return data.data.object;
			} catch (error) {
				if (error.response) {
					const errorMessage = error.response.data.message;
					throw new Error(errorMessage);
				} else {
					console.log(error);
					throw new Error("Network Error, please contact Notitia support");
				}
			}
		},
		refetchInterval: 5 * 60 * 1000,
	});
};

export default useObjectData;
