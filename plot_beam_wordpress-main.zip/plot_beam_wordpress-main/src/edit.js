import { TextControl, __experimentalText as Text } from "@wordpress/components";
/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import { __ } from "@wordpress/i18n";

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from "@wordpress/block-editor";

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import "./index.scss";

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @return {WPElement} Element to render.
 */
export default function Edit(props) {
	const blockProps = useBlockProps();
	return (
		<div className="plot-beam" {...blockPråops}>
			{__(
				<div className="admin-form">
					<TextControl
						className="form-text first"
						label="Object Title"
						type="text"
						help="Short title for the chart, 5 words max"
						value={props.attributes.objectTitle}
						onChange={(value) => props.setAttributes({ objectTitle: value })}
					/>
					<TextControl
						className="form-text"
						label="App ID"
						type="text"
						help="Demo App ID: da8c91fe-88fd-45ef-b573-596621f7ec6f"
						value={props.attributes.appID}
						onChange={(value) => props.setAttributes({ appID: value })}
					/>
					<TextControl
						className="form-text"
						label="Object ID"
						type="text"
						help="Demo Object ID: 576c5fc2-e038-4c90-b682-4e17b2fd846e"
						value={props.attributes.objectID}
						onChange={(value) => props.setAttributes({ objectID: value })}
					/>
					<TextControl
						className="form-text last"
						label="description"
						type="text"
						help="Short description for the chart, 100 words max"
						value={props.attributes.description}
						onChange={(value) => props.setAttributes({ description: value })}
					/>
					<Text className="support">
						For assistance, please visit our Support Portal at{" "}
						<a
							className="notitia"
							src="https://notitia.atlassian.net/servicedesk/customer/portals"
						>
							Notitia Support
						</a>
					</Text>
				</div>
			)}
		</div>
	);
}
