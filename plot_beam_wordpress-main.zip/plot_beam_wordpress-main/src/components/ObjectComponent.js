import React from 'react';
// import GaugeComponent from './GaugeComponent';
import useObjectData from '../hooks /useObjectData';
import brandIcon from '../../assets/brandIcon.svg';
import GaugeChartComponent from './GaugeChartComponent';

// import ChartSwith from './ChartSwith';
/**
 * @typedef {Object} Attributes
 * @property {string} objectTitle
 * @property {string} appID
 * @property {string} objectID
 * @property {string} gaugeID object ID for gauge object from Qlik Sense
 * @property {string} description
 */
/**
 * this is the main component to carry out fetching qliksense object data and pass to its children
 *
 * @param {Attributes} props
 *
 * @returns {React.JSX.Element}
 */
const ObjectComponent = ( { props } ) => {
	const { objectTitle, appID, objectID, description } = props;
	const {
		data: chartData,
		error,
		isLoading,
	} = useObjectData( objectID, appID );

	return (
		<div className="card">
			<div className="card-title">
				{ objectTitle }
				<img className="card-icon" src={ brandIcon } alt="icon" />
			</div>

			<div className="card-body">
				{ chartData && (
					<div className="card-chart-title">
						{ chartData.measurements[ 0 ] }
					</div>
				) }
				<div className="card-chart">
					{ error && (
						<div className="card-chart card-error">
							Something went wrong : { error.message }
						</div>
					) }
					{ isLoading && (
						<div className="card-chart">
							<div class="custom-loader"></div>
						</div>
					) }
					{ chartData && <GaugeChartComponent gauge={ chartData } /> }
				</div>

				{ chartData && (
					<div className="card-description">{ description }</div>
				) }
			</div>
		</div>
	);
};

export default ObjectComponent;
