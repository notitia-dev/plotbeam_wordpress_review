/* eslint-disable no-console */
console.log( 'Hello World! (from create-block-qlik-object block)' );
/* eslint-enable no-console */
