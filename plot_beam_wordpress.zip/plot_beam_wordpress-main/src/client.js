import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import './client.scss';
import ObjectComponent from './components/ObjectComponent';

/**
 * Create a new instance of QueryClient with default options.
 * @type {QueryClient}
 */

const queryClient = new QueryClient( {
	defaultOptions: {
		queries: {
			cacheTime: 5 * ( 60 * 1000 ), // 5 mins
			retry: 2,
		},
	},
} );
/**
 * Function to be executed when the DOM is loaded.
 * It renders ObjectComponents on specific DOM elements.
 * @function
 */
document.addEventListener( 'DOMContentLoaded', function () {
	/**
	 * Select all DOM elements with the class "qlik-vis-switch"
	 * and render ObjectComponents on each of them.
	 */
	const objectsToRender = document.querySelectorAll( '.qlik-vis-block' );
	/**
	 * Render ObjectComponent on each selected DOM element.
	 * @param {HTMLElement} object - The DOM element to render the ObjectComponent on.
	 */

	objectsToRender.forEach( function ( object ) {
		// Parse the data from the innerHTML of the "pre" element
		const props = JSON.parse( object.querySelector( 'pre' ).innerHTML );
		// Render ObjectComponent inside React.StrictMode and QueryClientProvider
		ReactDOM.render(
			<React.StrictMode>
				<QueryClientProvider client={ queryClient }>
					<ObjectComponent props={ props } />
				</QueryClientProvider>
			</React.StrictMode>,
			object
		);

		// Remove the "qlik-vis-sheet" class from the DOM element once it's rendered
		object.classList.remove( 'qlik-vis-block' );
		object.classList.add( 'wp-block-create-block-plot-beam' );
	} );
} );
