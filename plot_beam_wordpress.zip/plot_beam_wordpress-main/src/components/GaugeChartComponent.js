import React from 'react';
import GaugeComponent from 'react-gauge-component';

const GaugeChartComponent = ( { gauge } ) => {
	const min = gauge.measureAxis.min;
	const max = gauge.measureAxis.max;
	const percentage = ( gauge.exactData[ 0 ] - min ) / ( max - min );
	return (
		<GaugeComponent
			className="card-chart"
			arc={ {
				width: 0.2,
				cornerRadius: 9,
				subArcs: [
					{
						limit: 20,
						color: '#871D26',
						showMark: true,
					},
					{
						limit: 40,
						color: '#DA0316',
						showMark: true,
					},
					{
						limit: 60,
						color: '#FDA701',
						showMark: true,
					},
					{
						limit: 80,
						color: '#70B1A0',
						showMark: true,
					},
					{
						limit: 100,
						color: '#4B796D',
						showMark: true,
					},
				],
			} }
			pointer={ {
				elastic: true,
			} }
			labels={ {
				valueLabel: {
					matchColorWithArc: false,
					style: {
						fill: '#4D4D4D',
						fontSize: '20px',
						fontWeight: 600,
						textShadow: 'none',
					},
				},
			} }
			value={ percentage * 100 }
			minValue={ 0 }
			maxValue={ 100 }
		/>
	);
};

export default GaugeChartComponent;
